self.importScripts('./assets/background.js-CfqSLQa8.js');
